<?php /*
			 Template Name: testimonials
		*/
?>

<?php get_header(); ?>
<!-- Begin #main -->
<div id="main">
   <div class="post">
<div class="post-title">Testimonials</div>

Here are a few quotes from some of those infinitely intelligent thought mechanics readers. Thank you so much for your kind words, you all have wisdom beyond your years!

<br /><div style="border-bottom: 1px dotted #999;">&nbsp;</div>

<br />
<i>Excellent post here. Wow. I am going to link this post somewhere on my site, because it's very true and very good. Excellent reasoning.</i> -<a href="http://krisandapril.us/">April</a> [<a href="http://www.thoughtmechanics.com/blog/2005/03/11/more-aversive-racism/">More Aversive Racism</a>]

<br /><br />
<i>Theron, the more I read of your thoughts, the more I am amazed that you call yourself a liberal. A Constitutionalist I could understand but not a liberal. Looking at how the left & the right are both trying to control major media etc, and your espousing free thought (oh my God, the horror of it all) puts you outside of both of these camps.</i> -<a href="http://pcmedicofga.com">Dave</a> [<a href="http://www.thoughtmechanics.com/blog/2005/01/04/pyrolysis-of-thought/">Pyrolysis of Thought</a>]

<br /><br />
<i>I was just here to view your WordPress theme, but am now subscribing to your blog. Excellent observations on the influence society has on our religious beliefs.</i> -Ryan [<a href="http://www.thoughtmechanics.com/blog/2005/03/02/symbols-for-the-symbol-minded/">Symbols for the Symbol-Minded</a>

<br /><br />
<i>Good commentary. Agree with you totally. I'd been in my own CG consulting business since 1995, and recently worked for a large corporation as an employee. Even though it was a cool project, I realized that I couldn't go back to that blind follower mentality that corporations demand.</i> -<a href="http://www.mediaspin.com/blog/">Hank Grebe</a> [<a href="http://www.thoughtmechanics.com/blog/2005/02/13/workplace-homogenization/">Workplace Homogenization</a>]

<br /><br />
<i>I agree with you 100% the show was just lame and boring, even with paul singing they could have come up with other things to be happening and making it look cooler but it was dumb.</i></a> -<a href="http://www.jnetty.com/">Jnetty</a> [<A href="http://www.thoughtmechanics.com/blog/2005/02/08/the-congenial-halftime-show/">The Congenial Halftime Show</a>]

<br /><br />
<i>Man it's good to hear someone echo my thoughts! It seems as if we're on a downward spiral that just won't end until the world is in total chaos. The Dems just have to draw a line in the sand and stick to it - not be wishy-washy and try and please everyone. What is wrong indeed with helping others? The so-called "moral" party is so far from demonstrating any of the values held forth by any of the world's major religions that it's just laughable (if I weren't so damn depressed) when they start trying to align themselves with God. If God were the kind of God they believed in, she'd have smitten them all already for blasphemy! Good thing she's merciful.</i> -<a href="http://stoos.net">Michael</a> [<a href="http://www.thoughtmechanics.com/blog/2005/02/14/thanks-but-no-thanks/">Thanks, But No Thanks</a>]

<br /><br />
<i>Conservative. Wow! That word has a whole new meaning for me after the last two presidential elections. Once I thought conservatives were people who believed in less gov't aid programs (hence less taxes) and fiscal RESPONSIBILITY. Now I associate the word conservative with war mongering, bigotry, media manipulation and a big brother form of gov't. What a frightening differnece 8 years can make.</i> -<a href="http://www.raynchk.com/weblog/">Dale</a> [<a href="http://www.thoughtmechanics.com/blog/2005/03/11/more-aversive-racism/">More Aversive Racism</a>]

</div> </div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>