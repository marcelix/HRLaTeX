<!-- Begin #footer -->
<div id="footer"><hr />
  <p>This is the footer. Write something useful here.</p>

</div>
<!-- End #footer -->

</div>

</body>
</html>

