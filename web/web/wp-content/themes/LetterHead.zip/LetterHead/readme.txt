Hey! This is a fully free, fully functional theme for the Wordpress 1.5 blog utility. I have taken the bones of the Kubrick (default) theme and created one that reminds me a bit of the letterhead at the top of the MS Word Elegant Letter template. Wow! How's that for originality? Anyway - feel free to use the theme to your heart's content!

NOTES:
1. I've included a "post.php" page in the theme to allow you to make changes to the regularly formatted posts (those found in the index and archive pages) at one place and they will show up wherever you have standard posts. Non-standard posts can be found in the page.php file and the single.php file. Changes to the post.php page will not be reflected in those two files, unless you add the <?php require('post.php'); ?> line to those two pages.

2. There are no images included in this theme - so stop looking for them. This is a lightweight and accessible theme that requires no images to look good.

INSTALL:
Couldn't be easier. Unpack this archive in your wp-content/themes/ directory. Open the LetterHead director to make any changes you might need. Go to your Wordpress Admin page and use the Presentation menu item to "select" the LetterHead theme. Enjoy!

Questions or comments (or improvements) can be emailed to robin@rhastings.net. Drop me a line to let me know you are using this theme, will ya? I hate having to ego-surf all the time to see who's using my stuff... Thanks!!

Robin Hastings
robin@rhastings.net
http://www.rhastings.net - A Passion For 'Puters 